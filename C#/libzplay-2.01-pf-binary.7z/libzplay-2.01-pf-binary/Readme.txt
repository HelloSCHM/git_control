libZPlay library (WIN32) PF (patent free) version.

Version: 2.01
Date: May, 2010.

This is actually version 2.02 without support
for mp3 and aac format.