﻿/********************************************************************************
* @file		:	Common.h
* @summary	:	通用函数处理
* @author	:	Li Jiachun
* @time		:	2013-4-3 22:00:26
* @history	:	
********************************************************************************/
#ifndef __COMMON_H__
#define __COMMON_H__
#include <tchar.h>
#include <windows.h>

#define MAX_STRING (1000)

void ConvertIntToTCHAR(unsigned int , TCHAR[]);

#endif // __COMMON_H__
