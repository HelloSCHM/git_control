<!DOCTYPE TS><TS>
<context>
    <name>StandardDialogs</name>
    <message>
        <source>Standard Dialogs</source>
        <translation>标准对话框</translation>
    </message>
    <message>
        <source>File Dialog</source>
        <translation>  文件对话框  </translation>
    </message>
    <message>
        <source>Color Dialog</source>
        <translation>  颜色对话框  </translation>
    </message>
    <message>
        <source>Font Dialog</source>
        <translation>  字体对话框  </translation>
    </message>
    <message>
        <source>Hello World</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
